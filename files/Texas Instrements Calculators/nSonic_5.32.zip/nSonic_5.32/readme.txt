+------------+
| nSonic 5.3 |
+------------+

Comprehensive installation and setup how-to :
https://tiplanet.org/forum/viewtopic.php?f=57&t=17640

Introduction :
------------
nSonic is a fast folder browser which injects itself between the home screen and the TI-Nspire browser.
It lets you select a folder and then runs the TI-Nspire browser in that folder.

If you have many files on your TI-Nspire, opening the TI-Nspire browser from the home screen takes much time.
If you use nSonic and split your many files into several small folders, you'll be able to access them much faster.


First-time installation :
-----------------------
1) Send the "nSonic.tns" document to the "/ndless/startup" folder on your TI-Nspire (might need to be created)
2) On the TI-Nspire, open 'nSonic'

Update from a previous version :
------------------------------
1) Remove the "nSonic.tns" from the "/ndless/startup"
2) Reboot the TI-Nspire
3) Reactivate Ndless if necessary
4) Send the "nSonic.tns" document to the "/ndless/startup" folder on your TI-Nspire (might need to be created)
5) On the TI-Nspire, open 'nSonic'

Compatibility :
-------------
Compatible with :
- TI-Nspire CX II CAS + Ndless
- TI-Nspire CX II-T CAS + Ndless
- TI-Nspire CX II-C CAS + Ndless
- TI-Nspire CX II-T + Ndless
- all TI-Nspire CX + Ndless
- all TI-Nspire CM + Ndless
- all classic TI-Nspire + Ndless

Beware, not compatible with the TI-Nspire CX II.

Uninstallation :
--------------
1) Remove the "nSonic.tns" from the "/ndless/startup"
2) Reboot the TI-Nspire
3) Reactivate Ndless if necessary


Browser controls:
----------------

- change selected file/folder :
	* arrow up/down keys
	* numeric 8/2 keys
	* touchpad up/down zones (pressing the touchpad key is not required)

- browse selected folder :
	* arrow right key
	* numeric 6 key
	* touchpad right zone (pressing the touchpad key is not required)

- browse parent folder :
	* arrow left key
	* numeric 4 key
	* touchpad left zone (pressing the touchpad key is not required)

- validate selection (runs the TI-Nspire browser in selected folder) :
	* enter key
	* return key
	* click key

- runs the TI-Nspire browser in current folder :
	* esc key


Authors :
-------

Xavier Andreani: main code 
Excale: tricks + syscalls + TSR


Help / support :
--------------
http://tiplanet.org