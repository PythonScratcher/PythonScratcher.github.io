#define KEY_ROWS	8
uint16_t keysstate[KEY_ROWS];

int nbStateKeyPressed();
int anyStateKeyPressed();
void removeStateKey(t_key k);
void scanStateKeys();