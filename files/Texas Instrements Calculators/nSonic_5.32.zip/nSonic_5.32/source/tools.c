#include "os.h"
#include "config.h"
#include "tools.h"

void transform(uint8_t* data,int n) {
	uint64_t asicbasedkey = *(volatile uint64_t*) 0x900A0028;
	uint64_t key;
	int i;
	for(i=0;i<n;i++)
	{
		if(i%4)
			key=key>>8;
		else
			key=asicbasedkey;
		(*data)^=key;
		data++;
	}
}

void wait(int timesec)
{	volatile i;
	for(i=0;i<timesec*10000;i++) {}
}

int strStartsWith(char* str, char* start) {
	int lstart = strlen(start);
	int lstr = strlen(str);
	if(lstr<lstart) return 0;
	char* strback=malloc(lstr);
	memcpy(strback,str,lstr);
	*(strback+lstart)=0;
	int r=!strcmp(strback,start);
	free(strback);
	return r;
}

int getNumKey() {
	int r=-1;
	while(any_key_pressed());
	while(r==-1) {
		if(isKeyPressed(KEY_NSPIRE_ESC) || isKeyPressed(KEY_NSPIRE_UP)) { r=-1; break; }
		if(isKeyPressed(KEY_NSPIRE_ENTER) || isKeyPressed(KEY_NSPIRE_RET) || isKeyPressed(KEY_NSPIRE_DOWN)) { r=11; break; }
		if(isKeyPressed(KEY_NSPIRE_DEL) || isKeyPressed(KEY_NSPIRE_LEFT)) { r=10; break; }
		r=isKeyPressed(KEY_NSPIRE_0)?0:isKeyPressed(KEY_NSPIRE_1)?1:isKeyPressed(KEY_NSPIRE_2)?2:isKeyPressed(KEY_NSPIRE_3)?3:isKeyPressed(KEY_NSPIRE_4)?4:isKeyPressed(KEY_NSPIRE_5)?5:isKeyPressed(KEY_NSPIRE_6)?6:isKeyPressed(KEY_NSPIRE_7)?7:isKeyPressed(KEY_NSPIRE_8)?8:isKeyPressed(KEY_NSPIRE_9)?9:-1;
	}
	return r;
}