#include <os.h>
#include "nSonic.h"
#include "dirlist.h"
#include "browse.h"
#include "tools.h"
#include "types.h"
#include "keys.h"
#include "screen.h"
#include "console.h"

#define HEAD_LINES 4

#define UNDEF_PIN 0xFFFFFFFF
#define SCREEN_BYTES SCREEN_WIDTH*SCREEN_HEIGHT*2

								// non-CAS	CAS - look for 03 00 93 E8 08 D0 4D E2 before refresh_homescr
static const int addr_refresh[] = {
    0x1022F8FC,	0x10230028, // Clickpad / Touchpad 3.1
    0x1022F36C,	0x1022FAFC, // CX 3.1
    0x0, 		0x0,  		// CM 3.1
    0x102B6E38,	0x102B7878, // Clickpad / Touchpad 3.6
    0x102B68B4,	0x102B7324, // CX 3.6
    0x102BDFCC,	0x102BE510, // ClickPad / Touchpad 3.9.0
    0,			0, 			// ClickPad / Touchpad 3.9.1
    0, 			0, 			// CX 3.9.0
    0x102BE334, 0x102BE898,	// CX 3.9.1
    0, 			0, 			// CX 4.0.0
    0x102CD6FC, 0x102CDC38,	// CX 4.0.3
    0x102DDBF0,	0x102DE170, // CX 4.2
    0x102E4524, 0x102E4AB4, // CX 4.3
    0x102eb358,	0x102eb8e8, // CX 4.4
    0x102F2B48, 0x102F3148, // CX 4.5
    0x102F3A6C, 0x102F4190, // CX 4.5.1
//    0x102F41E8,	0x102F4910,	// CX 4.5.2
    0x102F42BC, 0x102F49E0, // CX 4.5.3
    0,		0x10323490,	0x10323D64,	// CX2 5.2.0
    0x102F4CB8, 	0x102F53DC, 	// CX 4.5.4
  0,		0x1032BD3C,	0x1032C674,	// CX2 5.3.0
};
#define REFRESH nl_osvalue((int*)addr_refresh, sizeof(addr_refresh)/sizeof(addr_refresh[0]))

	
extern unsigned char sscreen[SCREEN_BYTES];
uint16_t* offscreen;
uint16_t* screen;
char toppath[2][PATH_SIZE];

#define HOOK_PATH	"/nsonic.hook"
#define CONFIG_PATH	"/docsecret.access"
#define PUBLIC_MODE	0
#define HIDDEN_MODE	1

void clearScroll(uint16_t* buf) {
	setCurColorRGB(255,255,255);
	drawBufFullBox(buf,SCREEN_WIDTH-1-SCROLL_WIDTH,HEAD_HEIGHT2,SCREEN_WIDTH-1,SCREEN_HEIGHT);
	setCurColorRGB(0,0,0);
}

void loadConfig(uint16_t* keysstate, uint32_t* pin ) {
	*pin = UNDEF_PIN;
	FILE* h=fopen(CONFIG_PATH,"rb");
	if(h) {
		if(fread(keysstate,KEY_ROWS*sizeof(uint16_t),1,h))
			if(!fread(pin,sizeof(uint32_t),1,h))
				*pin=UNDEF_PIN;
			else {
				transform(pin,sizeof(uint32_t));
			}
		fclose(h);
	}
}

void saveConfig(uint32_t pin) {
	uint32_t encoded_pin=pin;	
	transform(&encoded_pin,sizeof(uint32_t));
	FILE* h=fopen(CONFIG_PATH,"wb");
	if(h) {
		if(fwrite(keysstate,KEY_ROWS*sizeof(uint16_t),1,h))
			fwrite(&encoded_pin,sizeof(uint32_t),1,h);
		fclose(h);
	}
}

int isValidPin(uint32_t pin) {
	return pin!=UNDEF_PIN;
}

uint32_t inputNewPin();

uint32_t inputPin(uint32_t pin0, char* msg, int allownewpin) {
	uint32_t pin=UNDEF_PIN;
	int num,c=0,i;
	if(!isValidPin(pin0)) {
		int lgn=getLine();
		displn("",0,1);
		disp("[     ] validates",0,1);
		setCol(0);
		setCurColorRGB(255,0,255);
		disp(" enter",0,1);
		setLine(lgn);
		setCol(0);
		setCurColorRGB(0,0,0);
	}
	disp(msg,0,1);
	while((pin!=pin0 || !isValidPin(pin0)) && c<9 && (num=getNumKey())>=0 && num<11) {
		if(num==10) {
			if(isValidPin(pin)) {
				pin=pin/10;
				c=max(c-1,0);
				memcpy(screen,sscreen,SCREEN_BYTES);
				clearScroll(screen);
				resetConsole(HEAD_LINES);
				disp(msg,0,1);
				for(i=0;i<c;i++)
					disp("*",0,1);
				if(c==0) pin=UNDEF_PIN;
			}
			else if(allownewpin && isValidPin(pin0)) {
				memcpy(screen,sscreen,SCREEN_BYTES);
				clearScroll(screen);
				resetConsole(HEAD_LINES);
				displn("Changing pin...",0,1);
				displn("\n",0,1);
				pin=inputPin(pin0,"Enter old pin   : ",0);
				if(pin==pin0) {
					displn("\n",0,1);
					pin=inputNewPin();
					if(isValidPin(pin)) {
						pin0=pin;
						saveConfig(pin0);
					}
				}
				break;
			}
		}
		else {
			if(!isValidPin(pin)) pin=0;
			pin=10*pin+num;
			disp("*",0,1);
			c++;
		}
	}
	if(num==-1)
		pin=UNDEF_PIN;
	displn("",0,1);
	return pin;
}

uint32_t inputNewPin() {
	uint32_t newpin1=UNDEF_PIN,newpin2=UNDEF_PIN;
	int s=1;
	while(newpin2!=newpin1 || !isValidPin(newpin1)) {
		if(!s) {
			resetConsole(HEAD_LINES);
			memcpy(screen,sscreen,SCREEN_BYTES);
			clearScroll(screen);
		}
		else
			s=0;
		newpin1=inputPin(UNDEF_PIN,"Enter new pin   : ",0);
		if(!isValidPin(newpin1)) break;
		displn("\n",0,1);
		displn("\n",0,1);
		newpin2=inputPin(newpin1,"Confirm new pin : ",0);
		displn("\n",0,1);
	}
	return newpin1;
}

void makeAllDirs(char* path) {
	char tmp[PATH_SIZE];
	char* p=path+1;
	int l;
	while(p=strchr(p,'/')) {
		p++;
		l=p-path;
		memcpy(tmp,path,l);
		tmp[l]=0;
		if(!isdir(tmp))
			mkdir(tmp,0);
	}
}

int moveContent(char* oldpath, char* newpath) {
	int r=0,errors=0;
	makeAllDirs(newpath);
	r=rename(oldpath,newpath);
	if(r<0 && isdir(oldpath)) {
		int numfiles,i,oldnumfiles=0;
		dirinfo* filenames=NULL;
		char *oldelementpath=malloc(PATH_SIZE),*newelementpath=malloc(PATH_SIZE);
		numfiles = dirlist(oldpath, &filenames,0,0);
		for(i=0;i<numfiles;i++) {
			strcpy(oldelementpath,oldpath);
			strcpy(newelementpath,newpath);
			strcat(oldelementpath,filenames[i].filename);
			strcat(newelementpath,filenames[i].filename);
			if(isdir(oldelementpath)) {
				strcat(oldelementpath,"/");
				strcat(newelementpath,"/");
			}
			if(!moveContent(oldelementpath,newelementpath))
				errors++;
		}
		if(filenames) free(filenames);
		free(oldelementpath);
		free(newelementpath);
		if(!errors)
			rmdir(oldpath);
	}
	return !errors;
}

void removeSilentKeys() {
	removeStateKey(KEY_NSPIRE_1);
	removeStateKey(KEY_NSPIRE_2);
	removeStateKey(KEY_NSPIRE_3);
	removeStateKey(KEY_NSPIRE_4);
	removeStateKey(KEY_NSPIRE_5);
	removeStateKey(KEY_NSPIRE_A);
	removeStateKey(KEY_NSPIRE_B);
	removeStateKey(KEY_NSPIRE_C);
	removeStateKey(KEY_NSPIRE_D);
	removeStateKey(KEY_NSPIRE_ENTER);
	removeStateKey(KEY_NSPIRE_CLICK);
	removeStateKey(KEY_NSPIRE_DEL);
	removeStateKey(KEY_NSPIRE_ESC);
	removeStateKey(KEY_NSPIRE_SCRATCHPAD);
	removeStateKey(KEY_NSPIRE_CTRL);
}

void dispStateKeys() {
	displn("   key(s) pressed :",0,1);
	displn("     home non-silent key(s) ignored",0,1);
	displn("     valid key(s)",0,1);
}

void updateStateKeys(int lgn) {
	int n1,n2;
	setCurColorRGB(0,0,255);
	scanStateKeys();
	setLine(lgn);
	setCol(0);
	n1=nbStateKeyPressed();
	disp(" ",0,1);
	dispi(n1,0,0);
	displn("",0,1);
	removeSilentKeys();
	n2=nbStateKeyPressed();
	disp("  ",0,1);
	dispi(n1-n2,0,0);
	displn("",0,1);
	disp("  ",0,1);
	dispi(n2,0,0);
	displn("",0,1);
	setCurColorRGB(0,0,0);
}

HOOK_DEFINE(hook) {
	int i, lgn, bline=0;
	int r,l;
	char del=0;
	char path[PATH_SIZE];
	del=isKeyPressed(KEY_NSPIRE_DEL);
	scanStateKeys();
	removeSilentKeys();
	int mode = PUBLIC_MODE;

	uint16_t savedkeysstate[KEY_ROWS];
	uint32_t pin0=UNDEF_PIN;	

	startScreen();
	screen = getScreen();
	uint16_t* baseoffscreen = (uint16_t*) malloc(SCREEN_BYTES+(has_colors?7:0));
	offscreen = baseoffscreen;
	memcpy(screen,sscreen,SCREEN_BYTES);
	clearScroll(screen);
	if(has_colors)
	{	r = ((uint32_t)offscreen)%8;
		if(r)
			offscreen=(uint16_t*)(((uint32_t)offscreen)+8-r);
	}
	resetConsole(HEAD_LINES);
	loadConfig(savedkeysstate,&pin0);
	if(!isValidPin(pin0) && anyStateKeyPressed() || isValidPin(pin0) && !memcmp(savedkeysstate,keysstate,KEY_ROWS*sizeof(uint16_t))) mode=HIDDEN_MODE;
	*(volatile unsigned*)0x90060C00 = 0x1ACCE551;
	*(volatile unsigned*)0x90060008 = 0;
	*(volatile unsigned*)0x90060C00 = 0;
    int intmask = TCT_Local_Control_Interrupts(-1);
    char *rootpath =get_documents_dir();

	if(mode==HIDDEN_MODE) {
		uint32_t pin;
		if(!isValidPin(pin0)) {
			displn("Catched new secret key(s)...",0,1);
			displn("\n",0,1);
			pin0=inputNewPin();
			if(isValidPin(pin0)) {
				displn("\n",0,1);
				displn("Confirm new secret key(s).",0,1);
				memcpy(savedkeysstate,keysstate,KEY_ROWS*sizeof(uint16_t));
				lgn=getLine();
				while(any_key_pressed());
				dispStateKeys();
				do
					updateStateKeys(lgn);
				while(!isKeyPressed(KEY_NSPIRE_ESC) && memcmp(savedkeysstate,keysstate,KEY_ROWS*sizeof(uint16_t)));
				if(!memcmp(savedkeysstate,keysstate,KEY_ROWS*sizeof(uint16_t))) {
					saveConfig(pin0);
					pin=pin0;
				}
			}
		}
		else {
			if(del) {
				displn("Secret keys change requested...",0,1);
				displn("\n",0,1);
			}
			pin=inputPin(pin0,"Enter pin   : ",1);
			if(del) {
				displn("\n",0,1);
				displn("Hold new secret key(s).",0,1);
				lgn=getLine();
				while(any_key_pressed());
				dispStateKeys();
				disp("[     ] validates",0,1);
				setCol(0);
				setCurColorRGB(255,0,255);
				disp(" enter",0,1);
				setLine(lgn);
				setCol(0);
				setCurColorRGB(0,0,0);
				do
					updateStateKeys(lgn);
				while(!isKeyPressed(KEY_NSPIRE_ESC) && !isKeyPressed(KEY_NSPIRE_ENTER));
				displn("\n",0,1);
				if(!isKeyPressed(KEY_NSPIRE_ESC) && anyStateKeyPressed()) {
					memcpy(savedkeysstate,keysstate,KEY_ROWS*sizeof(uint16_t));
					displn("\n",0,1);
					displn("Confirm new secret key(s).",0,1);
					lgn=getLine();
					while(any_key_pressed());
					dispStateKeys();
					do
						updateStateKeys(lgn);
					while(!isKeyPressed(KEY_NSPIRE_ESC) && memcmp(savedkeysstate,keysstate,KEY_ROWS*sizeof(uint16_t)));
					if(!memcmp(savedkeysstate,keysstate,KEY_ROWS*sizeof(uint16_t)))
						saveConfig(pin0);
					else
						pin=UNDEF_PIN;
				}
				else
					pin=UNDEF_PIN;					
			}
		}
		loadConfig(savedkeysstate,&pin0);
		if(pin==pin0) {
			if(!strStartsWith(rootpath,toppath[HIDDEN_MODE]))
				strcpy(rootpath,toppath[HIDDEN_MODE]);
		}
		else mode=PUBLIC_MODE;
	}
	if(mode==PUBLIC_MODE) {
		if(!strStartsWith(rootpath,toppath[PUBLIC_MODE]))
			strcpy(rootpath,toppath[PUBLIC_MODE]);
	}
	*path=0;
	r=-1;
	strcpy(path,rootpath);
	while(r<0)
	{
		r=chooseFile(path,path,toppath[mode],&bline);
		if(r>=0)
			strcpy(rootpath,path);
		else {
			char* p;
			char* newpath[PATH_SIZE];
			p=path+strlen(toppath[mode]);
			if(mode==HIDDEN_MODE || strcmp(p,"ndless/") && memcmp(p,"ndless/startup/",15)) {
				strcpy(newpath,toppath[!mode]);
				strcat(newpath,p);
				moveContent(path,newpath);
			}
			p=strrchr(path,'/');
			*p=0;
			p=strrchr(path,'/');
			*(p+1)=0;
		}
	}
	stopScreen();
	free(baseoffscreen);
    TCT_Local_Control_Interrupts(intmask);
	HOOK_RESTORE_RETURN(hook);
}

void saveHook(uint32_t hook) {
	FILE* h=fopen(HOOK_PATH,"wb");
	if(h) {
		fwrite(&hook,sizeof(uint32_t),1,h);
		fclose(h);
	}
}

int loadHook(uint32_t* hook) {
	FILE* h=fopen(HOOK_PATH,"rb");
	if(h) {
		fread(hook,sizeof(uint32_t),1,h);
		fclose(h);
		return 1;
	}
	return 0;
}

int main(void) {
	uint32_t current_hook = *(volatile uint32_t*)REFRESH;
	uint32_t orig_hook;
	int r = loadHook(&orig_hook);
	initScreen();
	convertRGB565(sscreen,SCR_320x240_565);
	if(!r || orig_hook==current_hook || nl_isstartup()) {
		if(!r || nl_isstartup())
			saveHook(current_hook);
		HOOK_INSTALL(REFRESH, hook);
		char *rootpath =get_documents_dir();
		strcpy(toppath[PUBLIC_MODE],rootpath);
		strcpy(toppath[HIDDEN_MODE],rootpath);
		char *p=strrchr(toppath[HIDDEN_MODE],'/');
		*p=0;
		p=strrchr(toppath[HIDDEN_MODE],'/');
		*(p+1)=0;
		strcat(toppath[HIDDEN_MODE],"docsecret/");
		//offscreen=(unsigned short int*)malloc(SCREEN_BYTES);
		//memcpy(offscreen,sscreen,SCREEN_BYTES);
		offscreen=(uint16_t*)sscreen;
		setCurColorRGB(255,255,0);
		drwBufStr(offscreen,281,15,"5.32",0,1);
		setCurColorRGB(255,255,255);
		drwBufStr(offscreen,2,2+0*CHAR_HEIGHT,"   parent           current          (un)lock",0,1);
		drwBufStr(offscreen,2,2+1*CHAR_HEIGHT,"   selected         selected  selected dir.",0,1);
		drwBufStr(offscreen,2,2+0*CHAR_HEIGHT,"[ ]          [     ]          [     ]",0,1);
		drwBufStr(offscreen,2,2+1*CHAR_HEIGHT,"[ ]          [     ]",0,1);
		setCurColorRGB(0,255,255);
		drwBufStr(offscreen,0,2+0*CHAR_HEIGHT," <",0,1);
		drwBufStr(offscreen,3,2+1*CHAR_HEIGHT," >",0,1);
		drwBufStr(offscreen,2,2+0*CHAR_HEIGHT," -             Esc             shift",0,1);
		drwBufStr(offscreen,2,2+1*CHAR_HEIGHT," -            Enter",0,1);
		setCurColorRGB(0,0,0);
		//memcpy(sscreen,offscreen,SCREEN_BYTES);
		//free(offscreen);
		nl_set_resident();
//		if(!nl_isstartup()) show_msgbox("nSonic", "Installed hook.");
	}
//	else if(!nl_isstartup()) show_msgbox("nSonic", "Hook already installed.");
	return 0;
}