#include "os.h"
#include "types.h"
#include "keys.h"

#define IS_RC_PRESSED(r,c)	(!is_classic ^ ((is_touchpad ? !((*(volatile short*)(0x900E0000 + (r))) & (c)) : !((*(volatile short*)(0x900E0000 + (r))) & (c)))))
#define row2i(r)	(((r)-0x10)/2)

uint16_t keysstate[KEY_ROWS];

void removeStateKey(t_key k)
{	int r,c;
	if(is_touchpad)
	{	r=k.tpad_row;
		c=k.tpad_col;
	}
	else
	{	r=k.row;
		c=k.col;
	}
	keysstate[row2i(r)]&=~c;
}

int anyStateKeyPressed()
{	int i;
	for(i=0;i<KEY_ROWS;i++)
		if(keysstate[i])
			return 1;
	return 0;	
}

int nbStateKeyPressed()
{	int i,n=0;
	uint16_t s;
	for(i=0;i<KEY_ROWS;i++) {
		s=keysstate[i];
		while(s) {
			if(s%2) n++;
			s=s>>1;
		}
	}
	return n;	
}

void scanStateKeys()
{	int i=0;
	int c,r;
	memset(keysstate,0,sizeof(uint16_t)*KEY_ROWS);
	for(r=0x10;r<0x20;r+=2)
		for(c=1;c<=0x400;c*=2)
			if(IS_RC_PRESSED(r,c))
				keysstate[row2i(r)]|=c;
}
