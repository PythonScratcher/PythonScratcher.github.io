#define NDLESS20

#ifdef NDLESS20
	#define TOUCHPAD_SUPPORT
	#define ANYKEY_SUPPORT
	#define SLEEP_SUPPORT
#endif