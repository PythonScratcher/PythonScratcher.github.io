#include "types.h"

#define NBR_SIZE 16
#define NDLESS_CONFIG	"/documents/ndless/ndless.cfg.tns"

#define max(a,b) (((a)<(b))?(b):(a))
#define min(a,b) (((a)<(b))?(a):(b))

#define is_cx2 (nl_hwtype()==1 && nl_hwsubtype()==2)

void wait(int timesec);
int strStartsWith(char* str, char* start);
void transform(uint8_t* data,int n);
int getNumKey();