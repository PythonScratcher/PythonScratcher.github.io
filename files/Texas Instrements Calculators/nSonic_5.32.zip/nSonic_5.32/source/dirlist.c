#include <os.h>
#include <dirent.h>
#include "dirlist.h"

int mystrcmp(dirinfo* f1, dirinfo* f2)
{	return strcmp(f1->filename,f2->filename);
}

void sortlist(dirinfo* entries, int n)
{	if(n<=1) return;
	dirinfo tmp;
	int c,i;
	int start = 0;
	int end = n-1;
	for(i=1;i<=end;i++)
	{	c=mystrcmp(entries,entries+i*sizeof(dirinfo));
		printf("ref %s\n",entries[0].filename);
		if(c<0)
		{	memcpy(&tmp,&entries[end],sizeof(dirinfo));
			memcpy(&entries[end],&entries[i],sizeof(dirinfo));
			memcpy(&entries[i],&tmp,sizeof(dirinfo));
			end--;
			i--;
		}
		else if(c>0)
		{	memcpy(&tmp,&entries[start],sizeof(dirinfo));
			memcpy(&entries[start],&entries[i],sizeof(dirinfo));
			memcpy(&entries[i],&tmp,sizeof(dirinfo));
			start++;
		}
	}
	sortlist(entries,start);
	sortlist(entries+start+1,n-start-1);
}

int isdir(char* path) {
	struct stat s;
	s.st_mode=0;
	stat(path, &s);
	return s.st_mode & S_IFDIR;
}

int hascontent(char* path) {
  int r=0;
  DIR* dir;
  if (dir = opendir(path)) {
	struct dirent *dent;
	while((dent=readdir(dir))!=NULL && !r)
		r=!ISCURPARDIR(dent->d_name);
	closedir(dir);
  }
  return r;
}

int dirlist(char* path, dirinfo** pentries, int dironly, int maxfiles)
{ DIR* dir;
  struct dirent *dent;
  int i=0,is_dir=0;
  if (!(dir = opendir(path)))
    return -1;
  chdir(path);
  printf("scanning %d\n",path);
  while(dent=readdir(dir))
  { if(!ISCURPARDIR(dent->d_name))
	{	is_dir=isdir(dent->d_name);
		if(is_dir || !dironly) {
			if(pentries) {
				if(i>=maxfiles) {
					maxfiles++;
					*pentries=(dirinfo*)realloc(*pentries,maxfiles*sizeof(dirinfo));
				}
				strcpy((*pentries)[i].filename,dent->d_name);
				(*pentries)[i].content=is_dir && hascontent(dent->d_name);
			}
			i++;
		}
		
	}
  }
  closedir(dir);
  if(pentries) sortlist(*pentries,i);
  return i;
}
