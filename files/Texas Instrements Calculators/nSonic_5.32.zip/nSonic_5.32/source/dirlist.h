#define PATH_SIZE 256
#define MAX_DIRS	1024
#define MAX_FILES	8096

#define ISCURPARDIR(NAME)(!((NAME)[2]) && (NAME)[0]=='.' && (!((NAME)[1]) || (NAME)[1]=='.'))

typedef struct dirinfo
{	unsigned char content;
	char filename[PATH_SIZE];
} dirinfo;

extern int dirlist(char* path, dirinfo** result, int dironly, int maxfiles);
